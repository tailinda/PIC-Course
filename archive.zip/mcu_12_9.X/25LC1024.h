#ifndef _25LC1024_H
#define _25LC1024_H

unsigned char read_25LC1024(unsigned int);


#endif
