/*
 * File:   25LC1024.c
 * Author: henry
 *
 * Created on 2015年12月18日, 下午 2:11
 */


#include "xc.h"

unsigned char read_25LC1024(unsigned int addr)
{
    
}
